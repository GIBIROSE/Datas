package com.stepDefinition;

import io.cucumber.java.en.Given;

public class TagsDemo {
	
	@Given("This is Scenario1")
	public void this_is_Scenario1() {
	}

	@Given("This is Scenario2")
	public void this_is_Scenario2() {
	}

	@Given("This is Scenario3")
	public void this_is_Scenario3() {
	}

	@Given("This is Scenario4")
	public void this_is_Scenario4() {
	}

	@Given("This is Scenario5")
	public void this_is_Scenario5() {
	}

	@Given("This is Scenario6")
	public void this_is_Scenario6() {
	}

}
